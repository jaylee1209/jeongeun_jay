package InOut;

public abstract class Output {
	public abstract void outconsole(int wordcount);
	public abstract void outfile(int countedletter);
}
