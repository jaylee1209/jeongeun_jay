package InOut;

public abstract class Input {
	public abstract String inconsole();
	public abstract String infile();
}